import alpaca_trade_api as tradeapi
from decouple import config
from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from .models import User, Trade, Stock
from .helpers import get_stock_data, get_historical_data, generate_graph
import json
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import TradeForm
from collections import defaultdict

ALPACA_API_KEY = config('ALPACA_API_KEY')
ALPACA_SECRET_KEY = config('ALPACA_SECRET_KEY')
base_url = 'https://api.alpaca.markets'

api = tradeapi.REST(ALPACA_API_KEY, ALPACA_SECRET_KEY, base_url)

def portfolio(request):
    if not request.user.is_authenticated:
        return redirect('login')  # Redirect to login if the user is not logged in

    # Get all trades for the logged-in user
    trades = Trade.objects.filter(portfolio=request.user)

    # Calculate current positions
    positions = defaultdict(lambda: {'quantity': 0, 'total_value': 0.0})
    for trade in trades:
        symbol = trade.stock.symbol
        if trade.trade_type == 'buy':
            positions[symbol]['quantity'] += trade.quantity
            positions[symbol]['total_value'] += trade.quantity * float(trade.price_per_share)
        elif trade.trade_type == 'sell':
            positions[symbol]['quantity'] -= trade.quantity
            positions[symbol]['total_value'] -= trade.quantity * float(trade.price_per_share)

    # Filter out stocks with zero quantity (no active position)
    positions = {symbol: data for symbol, data in positions.items() if data['quantity'] > 0}
    print(f"Positions: {positions}")
    return render(request, 'portfolio.html', {
        'balance': request.user.balance,
        'positions': positions,
    })

def add_stock_to_list(request):
    if request.method == 'POST':
        stock_symbol = request.POST.get('stock_symbol', '').upper()  # Get the input from the form

        try:
            api.get_latest_trade(stock_symbol)
            if stock_symbol not in STOCK_TICKERS:
                STOCK_TICKERS.append(stock_symbol)  # Add to the list if valid
                messages.success(request, f"{stock_symbol} added successfully.")
            else:
                messages.warning(request, f"{stock_symbol} is already in the list.")
        except Exception:
            messages.error(request, f"Invalid stock symbol: {stock_symbol}")

    return redirect('stocks')  # Redirect back to the stocks page

STOCK_TICKERS = ['AAPL', 'GOOG', 'AMZN', 'TSLA', 'NVDA']

def stocks_view(request):
    stocks = []
    for ticker in STOCK_TICKERS:
        stock = get_stock_data(ticker)  # Get stock info
        stocks.append({'stock': stock})  # Add stock info to the list

    return render(request, 'stocks.html', {'stocks': stocks})


def stock_detail_view(request, stock_symbol):
    stock = get_object_or_404(Stock, symbol=stock_symbol.upper())
    balance = None
    error = None


    # If the user is authenticated, prepare balance and process the trade
    if request.user.is_authenticated:
        balance = request.user.balance

        if request.method == 'POST':
            quantity = int(request.POST.get('quantity', 0))
            trade_type = request.POST.get('trade_type')
            total_cost = Decimal(stock.price) * Decimal(quantity)

            # Process Buy
            if trade_type == 'buy':
                if request.user.balance >= total_cost:
                    request.user.balance -= total_cost
                    Trade.objects.create(
                        stock=stock,
                        portfolio=request.user,
                        quantity=quantity,
                        price_per_share=stock.price,
                        trade_type='buy',
                    )
                    request.user.save()
                else:
                    error = "Insufficient balance to complete the purchase."

            # Process Sell
            elif trade_type == 'sell':
                trades = Trade.objects.filter(
                    portfolio=request.user, stock=stock, trade_type='buy'
                )
                total_shares = sum([trade.quantity for trade in trades]) - \
                               sum([trade.quantity for trade in Trade.objects.filter(
                                   portfolio=request.user, stock=stock, trade_type='sell')])

                if total_shares >= quantity:
                    request.user.balance += total_cost
                    Trade.objects.create(
                        stock=stock,
                        portfolio=request.user,
                        quantity=quantity,
                        price_per_share=stock.price,
                        trade_type='sell',
                    )
                    request.user.save()
                else:
                    error = "Insufficient shares to sell."

            if not error:
                return redirect('stock_detail', stock_symbol=stock.symbol)
    historical_data = get_historical_data(stock_symbol)
    graph = generate_graph(historical_data, stock_symbol)

    return render(request, 'stock_detail.html', {
        'stock': stock,
        'balance': balance,
        'error': error,
        'graph': graph
    })


def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Automatically log in the user after signup
            messages.success(request, "Account created successfully!")
            return redirect(login)  # Replace 'home' with the name of your homepage URL
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, "Logged in successfully!")
            return redirect('home')  # Replace 'home' with the name of your homepage URL
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('login')

@login_required
def trade_list(request):
    trades = Trade.objects.filter(portfolio=request.user).order_by('-trade_date')  # Fetch all trades for the user
    return render(request, 'trades.html', {'trades': trades})

def home(request):
    return render(request, 'home.html')


