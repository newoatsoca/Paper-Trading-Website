import alpaca_trade_api as tradeapi
from decouple import config
from .models import Stock
from datetime import datetime, timedelta
import plotly.express as px

# Load API keys
ALPACA_API_KEY = config('ALPACA_API_KEY')
ALPACA_SECRET_KEY = config('ALPACA_SECRET_KEY')
base_url = 'https://api.alpaca.markets'

# Initialize Alpaca API
api = tradeapi.REST(ALPACA_API_KEY, ALPACA_SECRET_KEY, base_url)

def get_stock_data(ticker):
    trade = api.get_latest_trade(ticker)

    price = trade.price

    size = trade.size

    stock, created = Stock.objects.update_or_create(
        symbol=ticker,
        defaults={'price': price, 'size': size}
    )
    return stock

def get_historical_data(ticker):
    end = datetime.now()
    start = end - timedelta(days=90)  # Fetch data for the past 90 days

    start_str = start.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_str = end.strftime('%Y-%m-%dT%H:%M:%SZ')

    # Fetch historical data and reset the index
    bars = api.get_bars(ticker, timeframe="1Day", start=start_str, end=end_str).df
    bars.reset_index(inplace=True)

    # Ensure 'date' and 'close' columns exist
    if 'close' not in bars.columns:
        raise KeyError("The 'close' column is not available in the data.")

    # Rename and format columns
    bars.rename(columns={'timestamp': 'date'}, inplace=True)
    bars['date'] = bars['date'].dt.strftime('%Y-%m-%d')  # Format date as a string

    return bars[['date', 'close']]  # Return only required columns


def generate_graph(data, ticker):
    # Check if required columns exist
    if 'date' not in data.columns or 'close' not in data.columns:
        raise ValueError("Data must contain 'date' and 'close' columns for plotting.")

    # Create a line chart with Plotly
    fig = px.line(
        data,
        x='date',
        y='close',
        title=f'{ticker} Stock Prices',
        labels={'date': 'Date', 'close': 'Close Price'},
    )
    return fig.to_html()


