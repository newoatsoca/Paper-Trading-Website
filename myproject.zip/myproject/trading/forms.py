from django import forms
from .models import Trade

class TradeForm(forms.ModelForm):
    class Meta:
        model = Trade
        fields = ['quantity', 'trade_type']

        # Add custom widgets or placeholders if needed
        widgets = {
            'quantity': forms.NumberInput(attrs={'placeholder': 'Enter quantity'}),
            'trade_type': forms.Select(attrs={'class': 'form-select'}),
        }
