# trading/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('portfolio/', views.portfolio, name='portfolio'),
    path('trades/', views.trade_list, name='trades'),
    path('stocks/', views.stocks_view, name='stocks'),
    path('stocks/<str:stock_symbol>/', views.stock_detail_view, name='stock_detail'),
    path('signup/', views.signup_view, name='signup'),
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('home/', views.home, name='home'),
    path('add_stock/', views.add_stock_to_list, name='add_stock_to_list'),

]
