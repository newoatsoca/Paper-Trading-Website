from django.contrib import admin

# Register your models here.

from django.contrib import admin
from .models import Stock, User, Trade

admin.site.register(Stock)
admin.site.register(User)
admin.site.register(Trade)