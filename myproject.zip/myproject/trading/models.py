
from django.db import models
from django.contrib.auth.models import AbstractUser

class Stock(models.Model):
    symbol = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    price = models.FloatField(default=0.0)
    size = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.symbol} - {self.price} - {self.size}"

class User(AbstractUser):
    balance = models.DecimalField(max_digits=100, decimal_places=2, default=1000)  # starting balance



class Trade(models.Model):
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE)
    portfolio = models.ForeignKey(User, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price_per_share = models.DecimalField(max_digits=10, decimal_places=2)
    trade_date = models.DateTimeField(auto_now_add=True)
    trade_type = models.CharField(max_length=10, choices=[('buy', 'Buy'), ('sell', 'Sell')])

    def __str__(self):
        return f"{str(self.trade_type).capitalize()} {self.quantity} {self.stock.symbol}"